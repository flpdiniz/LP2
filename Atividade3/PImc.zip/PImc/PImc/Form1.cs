﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public static double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            { 
                MessageBox.Show("Insira um valor numérico!");
                Focus();
            }
            else if (peso <= 0)
            {
                MessageBox.Show("Peso deve ser maior que zero!");
                Focus();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Insira um valor numérico!");
                Focus();
            }
            else if (peso <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero!");
                Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);

            txtImc.Text = imc.ToString();

            if (imc <= 18.5)
                txtClassificacao.Text = "Magreza";
            else if (imc >= 18.5 && imc <= 24.9)
                txtClassificacao.Text = "Normal";
            else if (imc >= 25 && imc <= 29.9)
                txtClassificacao.Text = "Sobrepeso";
            else if (imc >= 30 && imc <= 39.9)
                txtClassificacao.Text = "Obesidade";
            else
                txtClassificacao.Text = "Obesidade Grave";

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtImc.Clear();
            txtClassificacao.Clear();

            peso = 0;
            altura = 0;
            imc = 0;

            txtPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
