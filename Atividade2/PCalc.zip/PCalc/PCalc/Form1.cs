﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        public static double num1, num2, resultado;

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("Insira um valor numérico válido!");
                Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Insira um valor numérico válido!");
                Focus();
            }
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMpy_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Impossível dividir por zero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            }
            else
                resultado = num1 / num2;
                txtResultado.Text = resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();

            num1 = 0;
            num2 = 0;
            resultado = 0;
            txtNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public Form1()
        {
            InitializeComponent();

        }

    }
}
