﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;



namespace PEstoque
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[3,3];
            string auxiliar = "";
            int prod1, prod2, prod3, prod4, prod5, prod6, prod7, prod8, prod9, prod10, prod11, prod12;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++) 
                {
                    auxiliar = Interaction.InputBox($"Digite as entradas do produto {i + 1}", "$da semana {j + 1}");
                    if (!int.TryParse(auxiliar, out vetor[i, j]))
                    {
                        MessageBox.Show("número inválido");
                        i--;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    prod1 = 
                   // lstboxSaida. = ("Total de Entradas do Produto: " + i + " Semana: " + j + " - " + vetor[i,j]);
                }
            }




        }
    }
}
