﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxSalario_Validated(object sender, EventArgs e)
        {
            
        }

        private void NupdFilhos_ValueChanged(object sender, EventArgs e)
        {

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double salFamilia, descINSS, descIPRF, salLiquido;
            double.TryParse(mskbxSalario.Text, out double salBruto);
            int.TryParse(nupdFilhos.Text, out int numFilhos);

            if (salBruto >= 800.47) {
                mskbxAliqINSS.Text = "7,65%";
                descINSS = ((7.65 / 100) * salBruto);
            }
            else if (salBruto <= 1050)
            {
                mskbxAliqINSS.Text = "8,65%";
                descINSS = ((8.65 / 100) * salBruto);
            }
            else if (salBruto <= 1400.77)
            {
                mskbxAliqINSS.Text = "9,00%";
                descINSS = ((9.00 / 100) * salBruto);
            }
            else if (salBruto <= 2801.56)
            {
                mskbxAliqINSS.Text = "11,00%";
                descINSS = ((11 / 100) * salBruto);
            }
            else
            {
                mskbxAliqINSS.Text = "Teto";
                descINSS = 308.17;
            }
            mskbxDescINSS.Text = descINSS.ToString();

            if (salBruto >= 1257.12)
            {
                mskbxAliqIPRF.Text = "Isento";
                descIPRF = 0;
            }
            else if (salBruto >= 2512.08)
            {
                mskbxAliqIPRF.Text = "15%";
                descIPRF = ((15 / 100) * salBruto);
            }
            else
            {
                mskbxAliqIPRF.Text = "27,5%";
                descIPRF = ((27.5 / 100) * salBruto);
            }
            mskbxDescIPRF.Text = descIPRF.ToString();

                if (salBruto >= 435.52)
                {
                    salFamilia = 22.33 * numFilhos;
                }
                else if (salBruto >= 654.61)
                {
                    salFamilia = 15.74 * numFilhos;
                }
                else
                {
                    salFamilia = 0;
                }
                mskbxSalFamilia.Text = salFamilia.ToString();
                mskbxSalFamilia.Text = "0";

            salLiquido = salBruto - descINSS - descIPRF + salFamilia;
            mskbxSalLiquido.Text = salLiquido.ToString();
        }
        }
    }
