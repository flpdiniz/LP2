﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public static double salBruto, salLiquido, salFamilia, dscntIRPF, dscntINSS, aliqINSS, aliqIPRF, numFilhos;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            numFilhos = Convert.ToDouble(NupFilhos.Value);

            if(salBruto <= 800.47)
            {
                aliqINSS = 0.0765;
                dscntINSS = aliqINSS * salBruto;
            }
            else if(salBruto <= 1050)
            {
                aliqINSS = 0.0865;
                dscntINSS = aliqINSS * salBruto;
            }
            else if(salBruto <= 1400.77)
            {
                aliqINSS = 0.09;
                dscntINSS = aliqINSS * salBruto;
            }
            else if(salBruto <= 2801.56)
            {
                aliqINSS = 0.11;
                dscntINSS = aliqINSS * salBruto;
            }
            else
            {
                dscntINSS = 308.17;
                txtAliqINSS.Text = "Teto";
            }

            txtAliqINSS.Text = (aliqINSS * 100).ToString();
            txtDescINSS.Text = dscntINSS.ToString();

            if(salBruto <= 1257.12)
            {
                txtAliqIRPF.Text = "Isento";
                txtDescIRPF.Text = "Isento";
            }
            else if(salBruto <= 2512.08)
            {
                aliqIPRF = 0.15;
                dscntIRPF = aliqIPRF * salBruto;
            }
            else
            {
                aliqIPRF = 0.275;
                dscntIRPF = aliqIPRF * salBruto;
            }

            txtAliqIRPF.Text = (aliqIPRF * 100).ToString();
            txtDescIRPF.Text = dscntIRPF.ToString();

            if (salBruto <= 435.52)
                salFamilia = 22.33 * numFilhos;
            else if (salBruto <= 651.41)
                salFamilia = 15.74 * numFilhos;
            else
                salFamilia = 0;

            txtSalFamilia.Text = salFamilia.ToString();

            salLiquido = salBruto - dscntINSS - dscntIRPF + salFamilia;
            txtSalLiquido.Text = salLiquido.ToString();

        }

        private void NupFilhos_Validated(object sender, EventArgs e)
        {
         
        }

        private void mskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalBruto.Text, out salBruto))
            {
                MessageBox.Show("Salário inválido! Insira um valor numérico!");
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caractér inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
