﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mskbLadoA = new MaskedTextBox();
            mskbLadoB = new MaskedTextBox();
            mskbLadoC = new MaskedTextBox();
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            lblResultado = new Label();
            btnValidar = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // mskbLadoA
            // 
            mskbLadoA.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            mskbLadoA.Location = new Point(270, 76);
            mskbLadoA.Mask = "0.0";
            mskbLadoA.Name = "mskbLadoA";
            mskbLadoA.Size = new Size(242, 39);
            mskbLadoA.TabIndex = 0;
            // 
            // mskbLadoB
            // 
            mskbLadoB.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            mskbLadoB.Location = new Point(270, 153);
            mskbLadoB.Mask = "0.0";
            mskbLadoB.Name = "mskbLadoB";
            mskbLadoB.Size = new Size(242, 39);
            mskbLadoB.TabIndex = 1;
            // 
            // mskbLadoC
            // 
            mskbLadoC.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            mskbLadoC.Location = new Point(270, 226);
            mskbLadoC.Mask = "0.0";
            mskbLadoC.Name = "mskbLadoC";
            mskbLadoC.Size = new Size(242, 39);
            mskbLadoC.TabIndex = 2;
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lblLadoA.Location = new Point(106, 79);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(98, 32);
            lblLadoA.TabIndex = 3;
            lblLadoA.Text = "LADO A";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lblLadoB.Location = new Point(106, 160);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(97, 32);
            lblLadoB.TabIndex = 4;
            lblLadoB.Text = "LADO B";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            lblLadoC.Location = new Point(106, 229);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(98, 32);
            lblLadoC.TabIndex = 5;
            lblLadoC.Text = "LADO C";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblResultado.Location = new Point(133, 334);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(190, 32);
            lblResultado.TabIndex = 6;
            lblResultado.Text = "Esse triângulo é:";
            // 
            // btnValidar
            // 
            btnValidar.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnValidar.Location = new Point(575, 76);
            btnValidar.Name = "btnValidar";
            btnValidar.Size = new Size(176, 90);
            btnValidar.TabIndex = 7;
            btnValidar.Text = "Validar";
            btnValidar.UseVisualStyleBackColor = true;
            btnValidar.Click += btnValidar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnLimpar.Location = new Point(575, 200);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(176, 90);
            btnLimpar.TabIndex = 8;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(798, 451);
            Controls.Add(btnLimpar);
            Controls.Add(btnValidar);
            Controls.Add(lblResultado);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Controls.Add(mskbLadoC);
            Controls.Add(mskbLadoB);
            Controls.Add(mskbLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox mskbLadoA;
        private MaskedTextBox mskbLadoB;
        private MaskedTextBox mskbLadoC;
        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private Label lblResultado;
        private Button btnValidar;
        private Button btnLimpar;
    }
}