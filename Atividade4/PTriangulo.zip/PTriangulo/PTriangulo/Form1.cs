namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public static double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(mskbLadoA.Text, out double ladoA) &&
                double.TryParse(mskbLadoB.Text, out double ladoB) &&
                double.TryParse(mskbLadoC.Text, out double ladoC) &&
                ladoA > 0 && ladoB > 0 && ladoC > 0)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    lblResultado.Text = "Esse tri�ngulo �: Equil�tero!";
                }
                else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA)
                {
                    lblResultado.Text = "Esse tri�ngulo �: Is�sceles!";
                }
                else
                {
                    lblResultado.Text = "Esse tri�ngulo �: Escaleno!";
                }
            }
            else
            {
                lblResultado.Text = "Digite valores v�lidos maiores que zero!";
            }
        }

        private void mskbLadoA_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            ladoA = 0;
            ladoB = 0;
            ladoC = 0;

            mskbLadoA.Clear();
            mskbLadoB.Clear();
            mskbLadoC.Clear();
            lblResultado.Text = "Esse tri�ngulo �:";
        }
    }
}